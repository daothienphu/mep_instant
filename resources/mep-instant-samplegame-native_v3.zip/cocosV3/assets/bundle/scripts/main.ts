
import { _decorator, Component, Node, Vec2, math, Vec3, Quat } from 'cc';
const { ccclass, property } = _decorator;

declare const MEPInstant : any;

@ccclass('Main')
export class Main extends Component {
    audio : any = null;
    @property({type: Number})
    rotateSpeed: number = 5;
    @property({type: Node})
    mainCameraNode: Node | null = null;
    @property({type: Node})
    soldierNode: Node | null = null;

    currentRotateSpeed: number = 0;
    
    onLoad(){
        MEPInstant.initializeAsync().then(() => {
            console.log('MEPInstant successfully');
            MEPInstant.startGameAsync().then(this.onStart.bind(this));
            MEPInstant.onPause(() => {
                this.pause();
            })
            MEPInstant.onResume(() => {
                this.resume();
            })
        })
    }

    update(deltaTime : number){

        let soldierPosition = this.soldierNode?.getWorldPosition();
        let cameraPosition = this.mainCameraNode?.getWorldPosition();
        if(soldierPosition && cameraPosition)
        {
            Vec3.rotateY(cameraPosition, cameraPosition, soldierPosition, this.currentRotateSpeed*deltaTime);
            this.mainCameraNode?.setWorldPosition(cameraPosition);
            this.mainCameraNode?.lookAt(soldierPosition);
        }
    }

    onStart(gameData:any) {
        console.log('MEPInstant start', JSON.stringify(gameData));
        this.audio = MEPInstant.createMusicPlayer({
            src:gameData.song.mp3Url,
            onLoad: this.onMusicLoaded.bind(this)
        })
    }

    onMusicLoaded() {
        this.audio.play();
        this.currentRotateSpeed = this.rotateSpeed;
    }

    pause(){
        console.log('MEPInstant pause');
        this.audio.pause();
    }

    resume(){
        console.log('MEPInstant resume');
        this.audio.resume();
    }
}

/**
 * [1] Class member could be defined like this.
 * [2] Use `property` decorator if your want the member to be serializable.
 * [3] Your initialization goes here.
 * [4] Your update function goes here.
 *
 * Learn more about scripting: https://docs.cocos.com/creator/3.0/manual/en/scripting/
 * Learn more about CCClass: https://docs.cocos.com/creator/3.0/manual/en/scripting/ccclass.html
 * Learn more about life-cycle callbacks: https://docs.cocos.com/creator/3.0/manual/en/scripting/life-cycle-callbacks.html
 */
